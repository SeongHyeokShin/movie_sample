package admin.movie.db;

public class Movie_urlDTO {
	private int num; // ��ȭ ��ȣ
	private String stillcut; // ��ƿ�� �̹��� ���
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getStillcut() {
		return stillcut;
	}
	public void setStillcut(String stillcut) {
		this.stillcut = stillcut;
	}

}
