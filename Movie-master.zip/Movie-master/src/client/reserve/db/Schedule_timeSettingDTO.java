package client.reserve.db;

public class Schedule_timeSettingDTO {
	private String day;
	private String theater;
	private int theaternum;
	private String title;
	private String time;
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getTheater() {
		return theater;
	}
	public void setTheater(String theater) {
		this.theater = theater;
	}
	public int getTheaternum() {
		return theaternum;
	}
	public void setTheaternum(int theaternum) {
		this.theaternum = theaternum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
	

}
